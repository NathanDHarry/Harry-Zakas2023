# Packages and custom functions







# Package Installation ----

# detach any currently loaded packages
lapply(names(sessionInfo()$otherPkgs), function(pkgs)
  detach(paste0('package:', pkgs), character.only = T, unload = T, force = T))


## a function to load the given packages or install and then load them if they are not installed
if (!requireNamespace("BiocManager", quietly = TRUE)){
  install.packages("BiocManager")
}
using.cran<-function(...) {
  libs<-unlist(list(...))
  req<-unlist(lapply(libs,require,character.only=TRUE))
  need<-libs[req==FALSE]
  if(length(need)>0){ 
    install.packages(need)
    lapply(need,require,character.only=TRUE)
  }
}
using.biocon<-function(...) {
  libs<-unlist(list(...))
  req<-unlist(lapply(libs,require,character.only=TRUE))
  need<-libs[req==FALSE]
  if(length(need)>0){ 
    BiocManager::install(need)
    lapply(need,require,character.only=TRUE)
  }
}

## CRAN Required packages ----
req.package.cran <- c("ape", "ggdendro", "scales", "webshot", "htmlwidgets", 
                      "kableExtra", "knitr", "enrichR", "ggpubr", "ggsignif", "ggrepel", 
                      "lemon", "scales", "gridExtra", "grid", "reshape2", "pheatmap",
                      "ggstance", "RColorBrewer", "plyr", "tidyverse", "Rcpp", 
                      "data.table", "cowplot", "lattice", "ggthemes", 
                      "VennDiagram", "grDevices", "seqinr", "ggvenn", "purrr")

## BIOCONDA Required packages ----
req.package.biocon <- c("DESeq2", "stringi", "GenomicRanges", "biomaRt", "RUVSeq")






### CRAN required packages 2 ----
req.package.cran <- c("ape", "pheatmap", "plyr", "tidyverse", "ggvenn")

### Bioconda required packages 2 ----
req.package.biocon <- c("DESeq2", "RUVSeq", "stringi")


using.cran(req.package.cran)
using.biocon(req.package.biocon)




# Colors ----
## deseq colors
colors.streb <- c("PP" = "forestgreen", "LL" = "darkorange1", "PL" = "purple", "LP" = "magenta")
shapes.streb <- c("PP" = 17, "LL" = 15, "PL" = 17, "LP" = 15)
## mode of inheritance colors
moiColors <- c("Underdominant" = "purple3", "Overdominant" = "magenta3", "Additive" = "firebrick3", "P Dominant" = "forestgreen", "L Dominant" = "darkorange1", "Uninformative" = "burlywood4", "Ambiguous" = "wheat3", "Conserved" = "cornflowerblue")
moi_colScale <- scale_colour_manual(name = "Mode of Inheritance", values = moiColors)
moi_colScale.reduced <- scale_colour_manual(name = "Mode of Inheritance", values = moiColors[c(1,2,3,4,5)])
moi_colFill <- scale_fill_manual(name = "Mode of Inheritance", values = moiColors)
moi_colFill.reduced <- scale_fill_manual(name = "Mode of Inheritance", values = moiColors[c(1,2,3,4,5)])

#Function to set custom colors for Dev_Types (Lecithotroph, Planktotroph, F1_L, F1_P)
scale_colour_sbene <- function(...){
  ggplot2::scale_colour_manual(
    values = c("P"="darkolivegreen4", "L" = "darkorange2", "L.Hy" = "goldenrod1", "P.Hy" = "chartreuse1", "L.L" = "tomato4", "L.P" = "aquamarine4", "P.P" = "aquamarine1", "P.L" = "tomato1"),
    ...
  )
}



# Functions ----
plot.data_PCA <- function(object, intgroup = "Genotype", ntop = 500, returnData = FALSE){
  rv <- rowVars(assay(object))
  select <- order(rv, decreasing = T)[seq_len(min(ntop, length(rv)))]
  pca <- prcomp(t(assay(object)[select, ]))
  percentVar <- pca$sdev^2/sum(pca$sdev^2)
  if (!all(intgroup %in% names(colData(object)))){
    stop("the argument 'intgroup' should specify columns of colData(dds)")
  }
  intgroup.df <- as.data.frame(colData(object)[, intgroup, drop = F])
  intgroup.df <- lapply(intgroup.df, factor)
  d <- data.frame("PC1" = pca$x[, 1], "PC2" = pca$x[, 2], "PC3" = pca$x[, 3], "PC4" = pca$x[, 4], "PC5" = pca$x[, 5], intgroup.df, "name" = colData(object)$sampleName)
  if (returnData) {
    attr(d, "percentVar") <- percentVar[1:4]
    return(d)
  }
}

plot.PCA <- function(PCAData, PCa, PCb, colo, shape = NULL){
  Pa <- as.character(paste("PC", PCa, sep=""))
  Pb <- as.character(paste("PC", PCb, sep=""))
  colo <- as.character(colo)
  colors.select <- list("Genotype" = scale_color_manual(values = colors.streb[(names(colors.streb) %in% PCAData$Genotype)]),
                        "seq_Run" = scale_color_manual(values = c("tc1" = "royalblue", "tc2" = "darkred")))
  
  ggplot(PCAData, aes_string(x = Pa, y = Pb, color = colo, label = "name", shape = shape)) +
    geom_point(size = 1.2, stroke = 1.5, alpha = 0.75) +
    colors.select[[colo]] +
    scale_y_continuous(limits = c((min(PCAData[,PCb]) - 5), (max(PCAData[,PCb]) + 5))) +
    scale_x_continuous(limits = c((min(PCAData[,PCa]) - 5), (max(PCAData[,PCa]) + 5))) +
    coord_fixed() +
    labs(color = "black",
         x = paste0(paste(Pa, ": ", sep = ""), round(attr(PCAData, "percentVar")[as.numeric(PCa)] * 100), "% variance"),
         y = paste0(paste(Pb, ": ", sep = ""), round(attr(PCAData, "percentVar")[as.numeric(PCb)] * 100), "% variance")) +
    theme(axis.text = element_text(size = 15), axis.title.x = element_text(margin = margin(t = 18,)),
          axis.title = element_text(size = 18), plot.title = element_text(size = 20), legend.text = element_text(size = 12), legend.title = element_text(size = 15)) +
    guides(color = guide_legend(gsub("\"","",deparse(substitute(colo)))), shape = guide_legend(gsub("\"","",deparse(substitute(shape)))))
}

# Inheritance mode test functions
pval.hist <- function(res.type.a.b, string.plot.name) {
  pdf(paste0(paste0(dir.output_moi, "pval.histogram."), deparse(substitute(res.type.a.b)), ".pdf"), width = 8, height = 6)
  use <- res.type.a.b$baseMean > metadata(res.type.a.b)$filterThreshold
  h1 <- hist(res.type.a.b$pvalue[!use], breaks=0:50/50, plot=FALSE)
  h2 <- hist(res.type.a.b$pvalue[use], breaks=0:50/50, plot=FALSE)
  colori <- c(`do not pass`="khaki", `pass`="powderblue")
  barplot(height = rbind(h1$counts, h2$counts), beside = FALSE,col = colori, space = 0, 
          main = string.plot.name, ylab="frequency")
  text(x = c(0, length(h1$counts)), y = 0, label = paste(c(0,1)),
       adj = c(0.5,1.7), xpd=NA)
  legend("top", fill=rev(colori), legend=rev(names(colori)))
  dev.off()
}

Allele_count <- function(j, c, s) {
  SAMP <- c(".s1.data", ".s2.data", ".s3.data")
  sum(HyLiTE_data[[names(HyLiTE_data) == paste(LP[j], SAMP[s],sep="")]][,c], na.rm = T)
}
# Function for taking the mean of each sample's parental count
mAllele_count <- function(j, c) {
  SAMP <- c(".s1.data", ".s2.data", ".s3.data")
  mean(sum(HyLiTE_data[[names(HyLiTE_data) == paste(LP[j], SAMP[1],sep="")]][,c], na.rm = T),  
       sum(HyLiTE_data[[names(HyLiTE_data) == paste(LP[j], SAMP[2],sep="")]][,c], na.rm = T), 
       sum(HyLiTE_data[[names(HyLiTE_data) == paste(LP[j], SAMP[3],sep="")]][,c], na.rm = T), na.rm = T)
}



####
####
#### Clean up environment

rm(using.cran, using.biocon, req.package.cran, req.package.biocon)

####
####
####
